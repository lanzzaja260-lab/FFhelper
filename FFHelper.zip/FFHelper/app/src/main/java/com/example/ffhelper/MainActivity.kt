package com.example.ffhelper

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var btn: Button
    private lateinit var info: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun running() = prefs.getBoolean("running", false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply { text = "FF Helper"; textSize = 24f })

        btn = Button(this).apply { setOnClickListener { toggle() } }
        root.addView(btn)

        // ---- Crosshair ----
        root.addView(label("Bentuk crosshair"))
        val styles = arrayOf("Titik", "Plus", "Lingkaran")
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        styles.forEachIndexed { i, s ->
            rg.addView(RadioButton(this).apply { text = s; id = 100 + i })
        }
        rg.check(100 + prefs.getInt("style", 1))
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("style", id - 100).apply()
            pushUpdate()
        }
        root.addView(rg)

        root.addView(label("Warna"))
        val colors = intArrayOf(
            Color.RED, Color.GREEN, Color.CYAN, Color.YELLOW, Color.WHITE, Color.MAGENTA
        )
        val row = LinearLayout(this)
        colors.forEach { c ->
            row.addView(Button(this).apply {
                setBackgroundColor(c)
                layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply {
                    setMargins(dp(2), 0, dp(2), 0)
                }
                setOnClickListener {
                    prefs.edit().putInt("color", c).apply()
                    pushUpdate()
                }
            })
        }
        root.addView(row)

        slider(root, "Ukuran (dp)", "size", 10, 150, 60)
        slider(root, "Ketebalan (dp)", "thick", 1, 10, 3)
        slider(root, "Transparansi", "alpha", 30, 255, 255)
        slider(root, "Geser horizontal", "offx", -200, 200, 0)
        slider(root, "Geser vertikal", "offy", -200, 200, 0)

        // ---- Monitor performa ----
        root.addView(label("Monitor performa HP"))
        info = TextView(this).apply { textSize = 14f }
        root.addView(info)
        root.addView(action("Refresh status") { refresh() })
        root.addView(action("Mode hemat baterai (matikan!)") {
            open(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        })
        root.addView(action("Mode jangan ganggu (DND)") {
            open("android.settings.ZEN_MODE_PRIORITY_SETTINGS")
        })
        root.addView(action("Opsi pengembang") {
            open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        })
        root.addView(action("Buka Free Fire") { launchFF() })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- helpers ----------
    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun action(t: String, f: () -> Unit) =
        Button(this).apply { text = t; setOnClickListener { f() } }

    private fun slider(root: LinearLayout, title: String, key: String, lo: Int, hi: Int, def: Int) {
        val cur = prefs.getInt(key, def)
        val tv = label("$title: $cur")
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = cur - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.edit().putInt(key, p + lo).apply()
                tv.text = "$title: ${p + lo}"
                pushUpdate()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(tv)
        root.addView(sb)
    }

    private fun pushUpdate() {
        if (running()) {
            ContextCompat.startForegroundService(this, Intent(this, CrosshairService::class.java))
        }
    }

    private fun toggle() {
        if (!Settings.canDrawOverlays(this)) {
            // izin "Tampil di atas aplikasi lain"
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val i = Intent(this, CrosshairService::class.java)
        if (running()) stopService(i) else ContextCompat.startForegroundService(this, i)
        btn.postDelayed({ refresh() }, 300)
    }

    private fun open(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak tersedia di HP ini", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchFF() {
        val i = listOf("com.dts.freefireth", "com.dts.freefiremax")
            .firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (i != null) startActivity(i)
        else Toast.makeText(this, "Free Fire tidak terpasang", Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun refresh() {
        btn.text = if (running()) "STOP Crosshair" else "START Crosshair"

        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val pm = getSystemService(POWER_SERVICE) as PowerManager

        val thermal = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else -1
        val thermalTxt = when (thermal) {
            0 -> "Normal"
            1 -> "Hangat"
            2 -> "Panas sedang"
            3 -> "Panas (FPS bisa turun)"
            4, 5, 6 -> "Kritis, istirahatkan HP"
            else -> "Tidak tersedia"
        }
        val hz = windowManager.defaultDisplay.refreshRate

        info.text = buildString {
            appendLine("RAM kosong : ${mi.availMem / 1048576} MB / ${mi.totalMem / 1048576} MB")
            appendLine("Suhu       : $thermalTxt")
            appendLine("Hemat baterai : ${if (pm.isPowerSaveMode) "AKTIF (matikan)" else "mati"}")
            appendLine("Refresh layar : ${hz.toInt()} Hz")
            append("Overlay izin  : ${if (Settings.canDrawOverlays(this@MainActivity)) "OK" else "belum"}")
        }
    }
}
