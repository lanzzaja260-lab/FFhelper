package com.example.ffhelper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class CrosshairView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    var style = 1          // 0 = titik, 1 = plus, 2 = lingkaran + titik
    var sizePx = 120
    var thickPx = 4
    var color = Color.RED
    var alphaVal = 255

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(sizePx, sizePx)

    override fun onDraw(c: Canvas) {
        paint.color = color
        paint.alpha = alphaVal
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f - thickPx
        val t = thickPx.toFloat()
        when (style) {
            0 -> {
                paint.style = Paint.Style.FILL
                c.drawCircle(cx, cy, t * 1.2f, paint)
            }
            1 -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = t
                val gap = r * 0.25f
                c.drawLine(cx, cy - r, cx, cy - gap, paint)
                c.drawLine(cx, cy + gap, cx, cy + r, paint)
                c.drawLine(cx - r, cy, cx - gap, cy, paint)
                c.drawLine(cx + gap, cy, cx + r, cy, paint)
            }
            else -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = t
                c.drawCircle(cx, cy, r, paint)
                paint.style = Paint.Style.FILL
                c.drawCircle(cx, cy, t * 1.2f, paint)
            }
        }
    }
}
