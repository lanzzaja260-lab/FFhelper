package com.example.ffhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

class CrosshairService : Service() {

    private lateinit var wm: WindowManager
    private var view: CrosshairView? = null
    private var lp: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        render()
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("running", true).apply()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("xh", "Crosshair", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "xh")
        else Notification.Builder(this)
        val n = b.setContentTitle("Crosshair aktif")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun render() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val d = resources.displayMetrics.density

        val v = view ?: CrosshairView(this).also { view = it }
        v.style = p.getInt("style", 1)
        v.sizePx = (p.getInt("size", 60) * d).toInt()
        v.thickPx = (p.getInt("thick", 3) * d).toInt().coerceAtLeast(1)
        v.color = p.getInt("color", Color.RED)
        v.alphaVal = p.getInt("alpha", 255)

        val params = lp ?: WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }.also { lp = it }

        params.x = (p.getInt("offx", 0) * d).toInt()
        params.y = (p.getInt("offy", 0) * d).toInt()

        if (v.parent == null) {
            wm.addView(v, params)
        } else {
            v.requestLayout()
            v.invalidate()
            wm.updateViewLayout(v, params)
        }
    }

    override fun onDestroy() {
        view?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        view = null
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("running", false).apply()
        super.onDestroy()
    }
}
